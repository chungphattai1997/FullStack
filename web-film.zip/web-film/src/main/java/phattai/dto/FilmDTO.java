package phattai.dto;

import phattai.model.Film;

public class FilmDTO extends Film {
	private int id_category;

	public int getId_category() {
		return id_category;
	}

	public void setId_category(int id_category) {
		this.id_category = id_category;
	}

}
