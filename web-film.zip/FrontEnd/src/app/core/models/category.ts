export class Category {
    mId: number;
    mTitle: string;
    
    constructor (id: number, title: string) {
        this.mId = id;
        this.mTitle = title
    }
}