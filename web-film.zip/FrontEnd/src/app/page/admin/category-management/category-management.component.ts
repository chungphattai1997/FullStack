import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/core/services/category.service';
import { Category } from 'src/app/core/models/category';

@Component({
  selector: 'app-category-management',
  templateUrl: './category-management.component.html',
  styleUrls: ['./category-management.component.css']
})
export class CategoryManagementComponent implements OnInit {

  listCategory: Array<Category> = [];

  constructor(
    private categoryService: CategoryService
  ) { }

  ngOnInit() {
    let temp = this.categoryService.getAllCategory().subscribe(res => {
      this.listCategory = res;
      console.log(this.listCategory);
      temp.unsubscribe();
    }, err => {
      console.log(err);
      temp.unsubscribe();
    })
  }

}
