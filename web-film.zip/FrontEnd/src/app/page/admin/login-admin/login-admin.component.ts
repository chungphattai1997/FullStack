import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/core/services/user.service';
import { AuthGuard } from 'src/app/core/guards/auth.guard';

@Component({
  selector: 'app-login-admin',
  templateUrl: './login-admin.component.html',
  styleUrls: ['./login-admin.component.css']
})
export class LoginAdminComponent implements OnInit {

  constructor(
    private router: Router,
    private authGuard: AuthGuard,
    private userService: UserService
  ) { }

  ngOnInit() {
  }

  login(value) {
    let temp = this.userService.checkLogin(value.username, value.password).subscribe(res => {
      if (res.is_admin) {
        localStorage.setItem('admin', JSON.stringify(res));
        this.router.navigate(['/admin']);
      } else {
        alert('Tài khoản không có quyền admin!');
      }
      temp.unsubscribe();
    }, err => {
      console.log(err);
      alert('Sai thông tin đăng nhập!');
      temp.unsubscribe();
    })
  }

}
