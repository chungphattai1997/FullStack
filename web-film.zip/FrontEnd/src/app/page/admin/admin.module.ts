import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FilmManagementComponent } from './film-management/film-management.component';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
import { UserManagementComponent } from './user-management/user-management.component';
import { CategoryManagementComponent } from './category-management/category-management.component';
import { AdminLayoutComponent } from './admin-layout/admin-layout.component';
import { MainPanelComponent } from './admin-layout/main-panel/main-panel.component';
import { SideBarComponent } from './admin-layout/side-bar/side-bar.component';
import { FilmAddComponent } from './film-management/film-add/film-add.component';
import { FilmEditComponent } from './film-management/film-edit/film-edit.component';

const adminRoutes: Routes = [
  {
    path: '', component: AdminLayoutComponent, children: [
      { path: '', component: FilmManagementComponent },
      { path: 'user-management', component: UserManagementComponent },
      {
        path: 'film-management', component: FilmManagementComponent, children: [
          { path: 'add', component: FilmAddComponent }
        ]
      },
      { path: 'category-management', component: CategoryManagementComponent },
    ], canActivate: [AuthGuard]
  },

  { path: '**', pathMatch: 'full', redirectTo: '' }
];


@NgModule({
  declarations: [
    FilmManagementComponent,
    UserManagementComponent,
    CategoryManagementComponent,
    AdminLayoutComponent,
    MainPanelComponent,
    SideBarComponent,
    FilmAddComponent,
    FilmEditComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(adminRoutes)
  ]
})
export class AdminModule { }
