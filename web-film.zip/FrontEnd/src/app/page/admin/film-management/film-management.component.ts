import { Component, OnInit } from '@angular/core';
import { FilmService } from 'src/app/core/services/film.service';
import { Film } from 'src/app/core/models/film';

@Component({
  selector: 'app-film-management',
  templateUrl: './film-management.component.html',
  styleUrls: ['./film-management.component.css']
})
export class FilmManagementComponent implements OnInit {

  listFilm: Array<Film> = [];
  idFilm: number;
  
  constructor(
    private filmService: FilmService
  ) { }

  ngOnInit() {
    let temp = this.filmService.getAllFilm().subscribe(res => {
      this.listFilm = res;
      console.log(this.listFilm);
      temp.unsubscribe();
    }, err => {
      console.log(err);
      temp.unsubscribe();
    })
  }

}
