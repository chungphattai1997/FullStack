import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-film-edit',
  templateUrl: './film-edit.component.html',
  styleUrls: ['./film-edit.component.css']
})
export class FilmEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
