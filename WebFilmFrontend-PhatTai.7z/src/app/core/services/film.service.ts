import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Film } from '../models/film';

@Injectable({
  providedIn: 'root'
})
export class FilmService {

  constructor(
    private http: HttpClient
  ) { }

  getAllFilm() {
    let obs: Observable<any>;
    let url = 'http://localhost:8080/film/getall';
    obs = this.http.get(url);
    return obs;
  }

  addFilm(film: Film) {
    let obs: Observable<any>;
    let url = 'http://localhost:8080/film/add';
    obs = this.http.post(url, film);
    return obs;
  }
}
