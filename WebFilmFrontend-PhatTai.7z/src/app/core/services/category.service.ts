import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {

  constructor(
    private http: HttpClient
  ) { }

  getAllCategory() {
    let obs: Observable<any>;
    let url = 'http://localhost:8080/category/getall';
    obs = this.http.get(url);
    return obs;
  }
}
