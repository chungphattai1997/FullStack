import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { CategoryService } from 'src/app/core/services/category.service';
import { Category } from 'src/app/core/models/category';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import { FilmService } from 'src/app/core/services/film.service';
import { Film } from 'src/app/core/models/film';
declare var $;

@Component({
  selector: 'app-film-add',
  templateUrl: './film-add.component.html',
  styleUrls: ['./film-add.component.css']
})
export class FilmAddComponent implements OnInit {

  listCategory: Array<Category> = [];

  constructor(
    private toastr: ToastrService,
    private router: Router,
    private filmService: FilmService,
    private categoryService: CategoryService
  ) { }

  @ViewChild('addFilmForm') addFilmForm: NgForm;

  ngOnInit() {
    this.categoryService.getAllCategory().subscribe(res => {
      this.listCategory = res;
    }, err => {
      console.log(err);
    })
  }

  // validate() {
  //   if (!this.Movie.MaPhim) {
  //     this.toastr.error("Bạn chưa nhập mã phim!");
  //     return false;
  //   }
  //   if (!this.Movie.TenPhim) {
  //     this.toastr.error("Bạn chưa nhập tên phim!");
  //     return false;
  //   }
  //   if (!this.Movie.NgayKhoiChieu) {
  //     this.toastr.error("Bạn chưa nhập ngày khỏi chiếu!");
  //     return false;
  //   }
  //   if (!this.Movie.MoTa) {
  //     this.toastr.error("Bạn chưa nhập mô tả về phim!");
  //     return false;
  //   }
  //   if ($('#imgMovie')[0].files.length == 0) {
  //     this.toastr.error("Bạn chưa chọn hình ảnh!");
  //     return false;
  //   }
  //   if (!this.Movie.Trailer) {
  //     this.toastr.error("Bạn chưa nhập link trailer phim!");
  //     return false;
  //   }
  //   return true;
  // }

  onCancel() {
    this.router.navigate(['/admin/film-management']);
  }

  addFilm(value) {
    console.log(value);

    let film: Film = new Film (value.id, value.title, value.trailer, value.detail, value.dateOpening, value.rate, value.image, value.idCategory);

    this.filmService.addFilm(film).subscribe(res => {
      console.log(res.status);
      if (res.status == 201) {
        this.toastr.success(`Thêm phim ${film.title} thành công!`);
        this.router.navigate(['/admin/film-management']);
        console.log("done");
        
      }
    }, err => {
      console.log(err.status);
      this.toastr.error(err);
    });

  }

}
