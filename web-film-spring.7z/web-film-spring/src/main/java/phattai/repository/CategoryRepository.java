package phattai.repository;

import org.springframework.data.repository.CrudRepository;

import phattai.model.Category;

public interface CategoryRepository extends CrudRepository<Category, Long>{

}
