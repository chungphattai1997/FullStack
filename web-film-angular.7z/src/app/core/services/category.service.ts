import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {

  constructor(
    private http: HttpClient
  ) { }

  getAllCategory() {
    let obs: Observable<any>;
    let url = 'http://localhost:8080/category/getall';
    obs = this.http.get(url);
    return obs;
  }

  addCategory(data) {
    let obs: Observable<any>;
    let url = 'http://localhost:8080/category/add';
    obs = this.http.post(url, data);
    return obs;
  }

  updateCategory(data) {
    let obs: Observable<any>;
    let url = 'http://localhost:8080/category/update';
    obs = this.http.put(url, data);
    return obs;
  }

  deleteCategory(id) {
    let obs: Observable<any>;
    let url = `http://localhost:8080/category/delete/${id}`;
    obs = this.http.delete(url, { responseType: 'text' });
    return obs;
  }
}
