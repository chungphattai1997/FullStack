import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FilmService {

  constructor(
    private http: HttpClient
  ) { }

  getAllFilm() {
    let obs: Observable<any>;
    let url = 'http://localhost:8080/film/getall';

    let header = new HttpHeaders({
      'Authorization': 'Basic YWRtaW46YWRtaW4='
    });

    console.log(header.get("Authorization"));
    
    console.log(atob("YWRtaW46YWRtaW4="));

    obs = this.http.get(url, { headers: header });
    return obs;
  }

  getFilmById(id) {
    let obs: Observable<any>;
    let url = `http://localhost:8080/film/${id}`;

    obs = this.http.get(url);
    return obs;
  }

  addFilm(formData: FormData) {
    let obs: Observable<any>;
    let url = `http://localhost:8080/film/add`;
    obs = this.http.post(url, formData);
    return obs;
  }

  updateFilm(formData: FormData) {
    let obs: Observable<any>;
    let url = `http://localhost:8080/film/update`;
    obs = this.http.put(url, formData);
    return obs;
  }

  deleteFilm(id) {
    let obs: Observable<any>;
    let url = `http://localhost:8080/film/delete/${id}`;
    obs = this.http.delete(url, { responseType: 'text' });
    return obs;
  }
}
