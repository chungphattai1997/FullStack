import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Film } from '../models/film';

@Injectable({
  providedIn: 'root'
})
export class FilmService {

  constructor(
    private http: HttpClient
  ) { }

  getAllFilm() {
    let obs: Observable<any>;
    let url = 'http://localhost:8080/film/getall';
    obs = this.http.get(url);
    return obs;
  }

  getFilmById(id){
    let obs: Observable<any>;
    let url = `http://localhost:8080/film/${id}`;
    obs = this.http.get(url);
    return obs;
  }

  addFilm(formData: FormData) {
    let obs: Observable<any>;
    let url = `http://localhost:8080/film/add`;
    obs = this.http.post(url, formData);
    return obs;
  }
  
  updateFilm(formData: FormData) {
    let obs: Observable<any>;
    let url = `http://localhost:8080/film/update`;
    obs = this.http.put(url, formData);
    return obs;
  }

  deleteFilm(id) {
    let obs: Observable<any>;
    let url = `http://localhost:8080/film/delete/${id}`;
    obs = this.http.delete(url, { responseType: 'text' });
    return obs;
  }
}
